//
//  User.swift
//  SnapSnapApp
//
//  Created by Veldanov, Anton on 5/13/20.
//  Copyright © 2020 Anton Veldanov. All rights reserved.
//

import Foundation


struct User {
  var email = ""
  var uid = ""
}
